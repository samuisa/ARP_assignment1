#ifndef APP_BLACKBOARD_H
#define APP_BLACKBOARD_H

#define WIDTH  120
#define HEIGHT 40
#define INIT_X 2
#define INIT_Y 2

#endif
